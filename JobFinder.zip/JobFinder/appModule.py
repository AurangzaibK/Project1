def makeQueryFromFilters(request):
    three_days = request.form.get('three_days')
    today = request.form.get('today')
    remote = request.form.get('remote')
    onsite = request.form.get('onsite')
    hybrid = request.form.get('hybrid')
    project = request.form.get('project')
    part_time = request.form.get('part_time')
    full_time = request.form.get('full_time')
    internship = request.form.get('internship')
    fb = request.form.get('fb')
    amazon = request.form.get('amazon')
    netflix = request.form.get('netflix')
    apple = request.form.get('apple')
    google = request.form.get('google')
    micro = request.form.get('micro')
    linkedin = request.form.get('linkedin')
    deshaw = request.form.get('deshaw')
    atlassian = request.form.get('atlassian')
    urban = request.form.get('urban')
    alpha = request.form.get('alpha')
    cudy = request.form.get('cudy')

    query = "SELECT * FROM `job` WHERE"

    conditions = []
    if three_days:
        conditions.append("postedAt >= NOW() - INTERVAL 3 DAY")
    if today:
        conditions.append("postedAt >= CURDATE()")
    if remote:
        conditions.append("location = 'Remote'")
    if onsite:
        conditions.append("location = 'On Site'")
    if hybrid:
        conditions.append("location = 'Hybrid'")
    if project:
        conditions.append("job_type = 'Project'")
    if part_time:
        conditions.append("job_type = 'Part Time'")
    if full_time:
        conditions.append("job_type = 'Full Time'")
    if internship:
        conditions.append("job_type = 'Internship'")
    if fb:
        conditions.append("company_name = 'Fb'")
    if google:
        conditions.append("company_name = 'Google'")
    if netflix:
        conditions.append("company_name = 'Netflix'")
    if micro:
        conditions.append("company_name = 'Microsoft'")
    if apple:
        conditions.append("company_name = 'Apple'")
    if deshaw:
        conditions.append("company_name = 'DeShaw'")
    if atlassian:
        conditions.append("company_name = 'Atlassian'")
    if linkedin:
        conditions.append("company_name = 'Linkedin'")
    if alpha:
        conditions.append("company_name = 'Alpha Tech'")
    if cudy:
        conditions.append("company_name = 'Cudy Tech'")
    if conditions:
        query += " " + " OR ".join(conditions)

    
    return query