let dropDown = document.querySelector(".dropdown");
let profileDropDown = document.querySelector(".profile_dropdown");

const showDropDown = () => {
  console.log("called");
  if (dropDown.style.display === "block") {
    dropDown.style.display = "none";
  } else {
    dropDown.style.display = "block";
  }
};
const showProfileDropDown = () => {
  console.log("called showProfileDropDown");
  if (profileDropDown.style.display === "block") {
    profileDropDown.style.display = "none";
  } else {
    profileDropDown.style.display = "block";
  }
};

setTimeout(()=>{
  document.querySelector("#flashes").style.display = 'none'
},2500)