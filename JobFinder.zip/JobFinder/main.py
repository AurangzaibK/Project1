from flask import Flask, render_template, request, session, Response, redirect, flash
import mysql.connector
import os
from appModule import makeQueryFromFilters

app = Flask(__name__)
app.secret_key = 'saad@the@next_level_programmer'
# MySQL configurations
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'jobfinder'

mysql_conn = mysql.connector.connect(
    host=app.config['MYSQL_HOST'],
    user=app.config['MYSQL_USER'],
    password=app.config['MYSQL_PASSWORD'],
    database=app.config['MYSQL_DB']
)

# Optionally, you can create a cursor to execute queries
mysql_cursor = mysql_conn.cursor()


@app.route('/')
def home():
    query = "SELECT * FROM job ORDER BY postedAt DESC LIMIT 3"
    mysql_cursor.execute(query)
    res = mysql_cursor.fetchall()

    return render_template('index.html', jobs=res)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.form
        password = data['password']
        email = data['email']
        query = f"SELECT * FROM `user` WHERE email = '{email}'"

        print(query)
        mysql_cursor.execute(query)
        user = mysql_cursor.fetchone()
        if user == None:
            query = f"SELECT * FROM `user` WHERE name = '{email}'"
            mysql_cursor.execute(query)
            user = mysql_cursor.fetchone()

        if user == None:
            print('user not found')
            flash('invalid credential', 'danger')
        else:
            if user[6] == password:
                print(user[5], password, 'matched')
                session['user'] = user
                flash('You were successfully logged in', 'success')
                return redirect('/')
            else:
                flash('invalid credential', 'danger')

    return render_template('login.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        data = request.form
        email = data['email']
        name = data['name']
        experience = data['experience']
        age = data['age']
        current_status = data['current_status']
        city = data['city']
        expertise = data['expertise']
        password = data['password']
        contact = data['contact']
        query = f"INSERT INTO `user` (`email`, `name`, `contact`, `age`, `password`, `expertise`, `city`, `current_status`, `registeredAt`, `experience`) VALUES ( '{email}', '{name}', '{contact}', '{age}', '{password}', '{expertise}', '{city}', '{current_status}', current_timestamp(), '{experience}');"
        # query = f"SELECT * FROM your_table;"
        mysql_cursor = mysql_conn.cursor()
        mysql_cursor.execute(query)
        mysql_conn.commit()
        flash('You created account successfully', 'success')
        return redirect('/login',)
        # Process and return the result
        # print(result)
    return render_template('signup.html')


# ** JOB ROUTES
@app.route('/applications', methods=['GET', 'POST', 'DELETE', 'PUT'])
def applications():
    if not 'user' in session:
        return redirect('/login')
    email = session['user'][1]
    print(email)
    # query = f"SELECT * FROM `applications` WHERE email = '{email}'"
    query = f"SELECT applications.app_id, applications.email, applications.experience, applications.resume, applications.current_status, applications.appliedAt, job.id, job.job_title FROM applications JOIN job ON applications.job_id = job.id;"
    print(query)
    mysql_cursor = mysql_conn.cursor()
    mysql_cursor.execute(query)
    a = mysql_cursor.fetchall()
    length = len(a)
    print( length)
    return render_template('applications.html', applications=a, length=length)


@app.route('/application/delete', methods=['GET', 'POST', 'DELETE', 'PUT'])
def deleteApplication():
    id = request.args.get('id')
    print(id)
    query = f"DELETE FROM `applications` WHERE app_id = '{id}'"
    mysql_cursor = mysql_conn.cursor()
    mysql_cursor.execute(query)
    mysql_conn.commit()
    flash(f'application deleted with this id {id}','success')
    return redirect('/applications')


@app.route('/application', methods=['GET', 'POST', 'DELETE', 'PUT'])
def application():
    if request.method == 'POST':
        data = request.form
        # print(data)
        # resume = data['resume']
        experience = data['experience']
        job_id = data['job_id']
        email = data['email']
        current_status = data['current_status']
        # os.open('static','w')
        print(request.files)
        file = request.files['resume']
        # Check if the file has a filename
        if file.filename == '':
            return "No selected file", 400

        # Assuming you want to save the file with the original filename in the static folder
        # You can also modify the filename if required
        save_path = os.path.join(f"{app.static_folder}/resume", file.filename)
        file.save(save_path)
        query = f"INSERT INTO `applications` (`app_id`, `job_id`, `email`, `experience`, `current_status`, `resume`, `appliedAt`) VALUES (NULL, '{job_id}', '{email}', '{experience}', '{current_status}', '{file.filename}', current_timestamp());"

        mysql_cursor = mysql_conn.cursor()
        mysql_cursor.execute(query)
        mysql_conn.commit()
        flash('application submitted successfully','success')
        # Close the cursor and connection after the operation

        mysql_cursor.execute('SELECT * FROM `applications`')
        result = mysql_cursor.fetchall()
        # print(result)

    id = request.args.get('id')
    query = f"SELECT * FROM `job` WHERE id = '{id}'"
    mysql_cursor = mysql_conn.cursor()
    mysql_cursor.execute(query)
    result = mysql_cursor.fetchone()
    mysql_cursor.close()

    return render_template('application.html', job=result)


# Job is a particular Job that is based on query here user will apply on the paritcular job can delete application, edit and also can update it.
# todo -- get the id from query and filter the job 
@app.route('/job', methods=['GET', 'POST', 'DELETE', 'PUT'])
def job():
    id = request.args.get('id')
    query = f"SELECT * FROM `job` WHERE `id` = {id}"
    print(query)
    mysql_cursor.execute(query)
    result = mysql_cursor.fetchone()
    print(result)
    return render_template('job.html', job=result)


@app.route('/createjob', methods=['GET', 'POST', 'DELETE', 'PUT'])
def createJob():
    if request.method == 'POST':
        data = request.form
        title = data['title']
        hr = data['hr']
        company_name = data['company_name']
        lang = data['lang']
        location = data['location']
        requirements = data['requirements']
        job_type = data['job_type']
        experience = data['experience']
        print(data)
        query = f"INSERT INTO `job` (`id`, `job_title`, `hiring_person`,`experience`, `company_name`, `job_type`, `main_language`, `location`, `details`, `postedAt`) VALUES (NULL, '{title}', '{hr}',{experience}, '{company_name}', '{job_type}', '{lang}', '{location}', '{requirements}', current_timestamp());"
        mysql_cursor = mysql_conn.cursor()
        mysql_cursor.execute(query)
        mysql_conn.commit()

        # Close the cursor and connection after the operation
        mysql_cursor.close()
    return render_template('createjob.html')


@app.route('/profile', methods=['GET', 'POST', 'DELETE', 'PUT'])
def profile():
    if not 'user' in session:
        return redirect('/login')
        print('no item')
    else:
        print(session)
        email = session['user'][1]
        query = f"SELECT applications.app_id, applications.email, applications.experience, applications.resume, applications.current_status, applications.appliedAt, job.id, job.job_title FROM applications JOIN job ON applications.job_id = job.id WHERE applications.email = '{email}';"

        mysql_cursor.execute(query)
        res = mysql_cursor.fetchall()
        print(res)
        length = len(res)

    return render_template('profile.html', jobs=res, length=length)


@app.route('/jobs', methods=['GET', 'POST', 'DELETE', 'PUT'])
def jobsFunc():
    # This is for searching
    if request.method == 'POST':        
        data = request.form
        if 'query' in data:
            if len(data['query']) != 0:
                print(data['query'])
                query = f"SELECT * FROM `job` WHERE `job_title` = '{data['query']}'"
                mysql_cursor.execute(query)
                res = mysql_cursor.fetchall()
                return render_template('jobs.html', jobs=res)

        query = makeQueryFromFilters(request)
        print(query)
        mysql_cursor.execute(query)
        filtered_jobs = mysql_cursor.fetchall()
        return render_template('jobs.html', jobs=filtered_jobs)

    mysql_cursor.execute('SELECT * FROM `job`')
    res = mysql_cursor.fetchall()
    return render_template('jobs.html', jobs=res)


@app.route('/logout')
def logout():
    # Clear the user's session data
    session.clear()
    flash('You were successfully sign out', 'success')
    return redirect('/login')


if __name__ == "__main__":
    app.run(debug=True)
